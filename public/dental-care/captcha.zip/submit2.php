<?php
ob_start();
session_start();
extract($_POST);



$_SESSION['yname'] = $_POST[ 'name' ];
$_SESSION['ytel'] = $_POST[ 'phone' ];

// require_once('../class.phpmailer.php');
//$mail  = new PHPMailer();
include( '../connection.php' );
include( '../clicktocall.php' );


if ( empty( $_POST[ 'name' ] ) ) {	
	$error[ 'name_h' ] = 'Name cannot be left empty.';
	$error[ 'done' ] = "error";
} else if ( !preg_match( "/^[a-zA-Z\s ._-]+$/", $_POST[ 'name' ] ) ) {
	$error[ 'name_h' ] = 'Please enter valid name.';
	$error[ 'done' ] = "error";
} else {
	$error[ 'name_h' ] = '';
	$error[ 'done' ] = "";
}


//$ph_no_arr1 = array("8851672425","8178109008","7018140305","9877187263","9667732671","8268868995");
$ph_no_arr2 = array("08851672425","08178109008","07018140305","09877187263","09667732671","8268868995","9779585924","9313153084","8195098325","8195098325");
$ph_no_arr3 = array("+918851672425","+918178109008","+917018140305","+919877187263","+919667732671","8268868995");
if ( empty( $_POST[ 'phone' ] ) ) {
	$error[ 'tel_h' ] = 'Phone number cannot be left empty.';
	$error[ 'done' ] = "error";
} else if ( !empty( $_POST[ 'phone' ] ) && !is_numeric( $_POST[ 'phone' ] ) ) {
	$error[ 'tel_h' ] = 'Phone number must be number.';
	$error[ 'done' ] = "error";
} else if ( !empty( $_POST[ 'phone' ] ) && strlen( ( string )$_POST[ 'phone' ] ) != 10 ) {
	$error[ 'tel_h' ] = 'Phone number should be 10 digit.';
	$error[ 'done' ] = "error";
}else if(!preg_match('/^([6-9]{1})([0-9]{9})$/', $_POST[ 'phone' ])){
	$error[ 'tel_h' ] = 'Please use a valid number.';
	$error[ 'done' ] = "error";
}else	if ( !empty( $_POST[ 'phone' ] ) && (in_array($_POST[ 'phone' ],$ph_no_arr1) || in_array($_POST[ 'tel' ],$ph_no_arr2) || in_array($_POST[ 'phone' ],$ph_no_arr3)) ) 
{
	$error[ 'tel_h' ] = '*The phone number mentioned has been blocked due to multiple unscrupulous requests generated. Kindly use a different phone number to register your request.';
	$error[ 'done' ] = "error";
}
else {
	$error[ 'tel_h' ] = '';
	$error[ 'done' ] = "";
}



if ( $error[ 'name_h' ] == '' && $error[ 'tel_h' ] == '' && $error[ 'captcha_h' ] == '' ) {
	
//echo "Everything Fine"; exit;
	
	$name = $_POST[ 'name' ];
	$phone = $_POST[ 'phone' ];
	

	

	if ( $name != '' and $phone != '') {
//$to = "rohit@reinventdigital.com";	    
	 $to = "psperfectsmile@gmail.com, ultimatecosmeticdentist@gmail.com";
$headers .= "From: $name $email\n";
$headers.= "MIME-version: 1.0\n";
$headers.= "Content-type: text/html; charset= iso-8859-1\n";
$subject = 'Perfectsmile Appointment';
$messages = '<p>Dear Admin,</p><p>Please see the below appointment details.</p><table>
<tr><td><b>Name </b></td><td><b>:</b></td><td>'.$name.' </td></tr>
<tr><td><b>Phone </b></td><td><b>:</b></td><td>'.$phone.' </td></tr>
<tr><td><b>UTM Source </b></td><td><b>:</b></td><td>'.$email.'</td></tr>
<tr><td><b>UTM Medium </b></td><td><b>:</b></td><td>'.$utm_medium.'</td></tr>
<tr><td><b>UTM Campaign </b></td><td><b>:</b></td><td>'.$utm_campaign.'</td></tr>
<tr><td><b>UTM Term </b></td><td><b>:</b></td><td>'.$utm_term.'</td></tr>
</table><p>Kind Regards,<br />Vital Dental Care Team<br/>www.vitaldentalcare.co.in</p>';;
mail($to,$subject,$messages,$headers);   
	    
// // require_once('../class.phpmailer.php');
// // $mail  = new PHPMailer();
// $body = '<p>Dear Admin,</p><p>Please see the below appointment details.</p><table>
// <tr><td><b>Name </b></td><td><b>:</b></td><td>'.$name.' </td></tr>
// <tr><td><b>Phone </b></td><td><b>:</b></td><td>'.$phone.' </td></tr>
// <tr><td><b>UTM Source </b></td><td><b>:</b></td><td>'.$email.'</td></tr>
// <tr><td><b>UTM Medium </b></td><td><b>:</b></td><td>'.$utm_medium.'</td></tr>
// <tr><td><b>UTM Campaign </b></td><td><b>:</b></td><td>'.$utm_campaign.'</td></tr>
// <tr><td><b>UTM Term </b></td><td><b>:</b></td><td>'.$utm_term.'</td></tr>
// </table><p>Kind Regards,<br />Vital Dental Care Team<br/>www.vitaldentalcare.co.in</p>';
// $mail->IsSMTP(); // telling the class to use SMTP
// //$mail->Host       = "webmail.vitaldentalcare.co.in"; // SMTP server
// $mail->Host       = "vitaldentalcare.co.in";      // sets GMAIL as the SMTP server
// $mail->SMTPAuth   = true;                  // enable SMTP authentication
// //$mail->Host       = "webmail.vitaldentalcare.co.in";      // sets GMAIL as the SMTP server
// $mail->Username   = "smtp@vitaldentalcare.co.in";  // GMAIL username
// //$mail->Password   = "5x7c@)Dk!ss~";           // GMAIL password
// $mail->Password   = "FpYAglx{Umto";
// $mail->SetFrom('info@vitaldentalcare.co.in', 'info');
// $mail->AddReplyTo($email,$name);
// $mail->Subject    = "Make an Appointment";
// $mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test
// $mail->MsgHTML($body);
// $mail->AddAddress('rohit@reinventdigital.com', "info");

// //$mail->addBCC('dranurag13803@gmail.com',"info");

// $mail->Send();
	    
	    		$datetime = date( "Y-m-d H:i:s" );

	    $qry = "INSERT INTO leads(lead_created_date_time, lead_campaign_name, lead_source,lead_location, lead_name, lead_mobile, lead_email, treatments,lead_notes,	    lead_ppc_campaign, lead_ppc_source, lead_ppc_keyword, lead_ppc_medium, lead_ip_address, lead_region, clc_response) VALUES('" . $datetime . "', '".$url."', '" . $lead_source . "', '" . $city . "', '" . mysqli_real_escape_string( $con, $name ) . "', '" . mysqli_real_escape_string( $con, $phone ) . "', '" . mysqli_real_escape_string( $con, $email ) . "', '', '".$msg."', '" . $utm_campaign . "', '" . $utm_source . "', '" . $utm_term . "', '" . $utm_medium . "', '" . $leadipaddress . "', '', '". $response . "')";
//echo $qry; exit;
	     mysqli_query( $con, $qry ); 
	     header('Location:https://perfectsmile.co.in/dental-care/thank-you.html');
			exit;
		
	}	 
} else {
    
    
	if($error[ 'name_h' ] != ""){
		$_SESSION['error_issue'] = "Please enter only characters in name<br/>";
	}
	
	if($error[ 'tel_h' ] != ""){
		$_SESSION['error_issue'] .= "Please enter valid phone number";
	}
	header('location:'.$_SERVER['HTTP_REFERER']);
	//echo "Everything not Fine"; exit;
	//echo json_encode( $error );
}

//mysqli_close($con);

?>