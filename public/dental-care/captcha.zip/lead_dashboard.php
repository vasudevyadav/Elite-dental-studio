<?php

session_start();
$status = session_status();
if($status == "0"){
    //There is no active session
    session_start();
}
    include( 'connection.php' );


 

date_default_timezone_set( 'Asia/Calcutta' );


if($_SESSION["leadUser"]!="admin"){
    	header('location:login_dashboard.php');
	exit;
}
if(isset($_REQUEST['uname'])){$uname=$_REQUEST['uname'];}else{$uname='';}
if(isset($_REQUEST['lead_mobile'])){$lead_mobile=$_REQUEST['lead_mobile'];}else{$lead_mobile='';}
if(isset($_REQUEST['email'])){$email=$_REQUEST['email'];}else{$email='';}
if(isset($_REQUEST['order'])){
$order = $_REQUEST['order'];
}else{
	$order = "desc";
}
if($_REQUEST['datfrom']){
	$datfrom = date("Y-m-d", strtotime($_REQUEST['datfrom']));
}
if($_REQUEST['datto']){
	$datto = date("Y-m-d", strtotime($_REQUEST['datto']));
}
if($_REQUEST['export']=="Export"){
	  header('location: export_lead_data.php?datfrom='.$datfrom.'&datto='.$datto.'&uname='.$uname.'&lead_mobile='.$lead_mobile.'&email='.$email.'&order='.$order);
}

?>
<style type="text/css">
    body{margin: 0px;padding: 0px;}
#content{ width: 900px; margin: 0 auto; font-family:Arial, Helvetica, sans-serif;}
table{font-size: 13px !important;}
.page{ float: right; margin: 0; adding: 0; }
.page li { list-style: none; display:inline-block;}
.page li a, .current{ display: block; padding: 5px; text-decoration: none; color: #8A8A8A;}
.current{ font-weight:bold; color: #000; }
.button{padding: 5px 15px;text-decoration: none;background: #333;color: #F3F3F3;font-size: 13PX;border-radius: 2PX;margin: 0 4PX;display: block;float: left;}
.applydata_container table tr.applydata_head {position: relative;width: 100%;background: #CB964A  !important;color: #fff;cursor:default;}
.applydata_container table tr.applydata_head th {white-space: nowrap;color: #fff;padding: 10px;border-right: 1px solid #CB964A ;margin: 0px;font-weight: bold;text-align: center;text-transform: capitalize;}
.applydata_container table tr td {color: #000000;padding: 10px;border-right: 1px solid #c6c6c6;margin: 0px;border-bottom: 1px solid #c6c6c6;text-align: center;}
.applydata_container table tr:nth-child(even) {transition: all ease-in 0.3s;background: #e4e4e4;}
.applydata_container table tr:nth-child(odd) {background: #f0f0f0;transition: all ease-in 0.3s;}
.applydata_container table tr td a.apply_email_link {color: #471e0a;text-decoration: underline;transition: all ease-in 0.3s;outline: none;border: 0px;}
.applydata_container table tr td a.apply_email_link:link:focus,.applydata_container table tr td a.apply_email_link:visited:focus{ outline:none; -moz-outline: none;  -webkit-outline: none; -o-outline: none;  -ms-outline: none; box-shadow:none; -moz-box-shadow: none;  -webkit-box-shadow: none;  -o-box-shadow: none; -ms-box-shadow: none;}
.applydata_container table tr td:nth-child(3), .applydata_container table tr td:nth-child(7), .applydata_container table tr.applydata_head th:nth-child(3), .applydata_container table tr.applydata_head th:nth-child(7) {text-align: left;}
.applydata_container table tr{ cursor: pointer;}
.applydata_container table tr.applyTr_selected {  background: #CB964A; color: #ffffff;}
.applydata_container table tr.applyTr_selected td{ color:#ffffff;}
.applydata_container table tr.applyTr_selected td a.apply_email_link,
.applydata_container table tr.applyTr_selected td a.apply_email_link{color:  #ff8001;text-decoration: underline;}
.orderform_panel {float: left;margin: 0 0 10px;width: 100%;}
.filter_formrow,.orderform_panel{ width:100%; float: left; margin: 0px;    background: #CB964A;padding: 0px 20px;}
.orderform_panel{margin-bottom: 30px;color: #fff;}
    .orderform_panel select{width: 200px;height: 35px;border-radius: 4px; margin-bottom: 20px;}
.filter_formrow h3{font-size: 20px;font-weight: 600;color: #fff;font-family: "Open Sans", sans-serif;margin:7px 0 15px 0;}
.filter_formrow .search_filtercol{ width: auto;float: left; margin: 0 15px 0 0;}
.filter_formrow .search_filtercol label.lable_search_text{ float: left;min-width: 60px;margin: 3px 0 0 0;color: #fff;}
.filter_formrow.filter_Search label.lable_search_text{ float: left;min-width: 60px;margin: 3px 0 0 0;}
.pagination_applycontainer{width: 100%;float: left;text-align: center;padding: 10px 0 5px;}
.pagination_applycontainer a.button{ float:none;}
.pagination_applycontainer ul.page{ float: none;width: auto;display: inline-block; padding:0 2px;}
.pagination_applycontainer ul.page li a{ color: #555;background: #f7f7f7;-webkit-box-shadow: inset 0 1px 0 #fff, 0 1px 0 rgba( 0, 0, 0, 0.08 );box-shadow: inset 0 1px 0 #fff, 0 1px 0 rgba( 0, 0, 0, 0.08 );margin: 0 2px;padding-left: 10px;padding-right: 10px;border-radius: 3px; border: 1px solid #cccccc;line-height:normal;}
.pagination_applycontainer ul.page li a:hover{ background: #fafafa;border-color: #999;color: #222;}
.pagination_applycontainer ul.page li.current{ color: #555;background: #ff8001;-webkit-box-shadow: none;box-shadow: none;margin: 0 2px;padding-left: 10px;padding-right: 10px;border-radius: 3px; border: 1px solid #cc6601;line-height:normal;color: #fff;}
.input{-webkit-appearance: none;-moz-appearance: none;appearance: none;outline: 0;border: 1px solid #fff;width: 250px;border-radius: 3px;padding: 8px;margin: 0 auto 15px auto;display: block;text-align: left;font-size: 14px;color: #000;-webkit-transition-duration: 0.25s;transition-duration: 0.25s;font-weight: 300;resize: none;}
 .button2{background:#ffffffb0;border: none;padding:7px 20px;font-size: 17px;color: #000;border: none;border-radius:4px;margin-right: 10px;cursor:pointer;}
.lg-out{background: #000000a8;display: inline-block;padding: 10px 20px;color: #fff;text-decoration: none;border-radius: 4px;margin: 10px;float: right;}
    .lg-out:hover{background:#CB964A;color: #fff;}
    .applydata_container{width: 100%;float: left;overflow-x: scroll;}
    .pagination{width: 100%;float: left;padding: 20px 0px;text-align: center;}
    .pagination a,.pagination span{display: inline-block;margin: 0 10px;padding:6px 10px;text-decoration: none;color: #fff;background: #CB964A;}
    .pagination .current{background:#f57905;color: #fff;}
    body{overflow-x:hidden;}
</style>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="https://jqueryui.com/resources/demos/style.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $(".applydata_container table tr").click(function(){
        $(".applydata_container table tr").removeClass("applyTr_selected");
        $(this).addClass("applyTr_selected");
    });
   
});
</script> 
<a href="logout_dashboard.php" class="lg-out">Logout</a>
<form action="lead_dashboard.php" method="POST" name="apply_frm" id="apply_frm">
<div class="filter_formrow">				
	<h3>Search by</h3>
    <div class="search_filtercol"><input type="text" name="uname" placeholder="Name" value="<?php echo $_REQUEST['uname']; ?>" class="input"></div>
	<div class="search_filtercol"><input type="text" name="email" placeholder="Email" value="<?php echo $_REQUEST['email']; ?>" class="input"></div>
	<div class="search_filtercol"><input type="text" name="lead_mobile" placeholder="Mobile" value="<?php echo $_REQUEST['lead_mobile']; ?>" class="input"></div>
</div>	
	<div class="filter_formrow filter_Search">
	<h3>Filter by date</h3>
	<div class="search_filtercol"><input id="datepicker1" type="text" name="datfrom" placeholder="From" value="<?php if($datfrom){echo date('d F Y',strtotime($datfrom));}?>" class="input"></div>
	<div class="search_filtercol"><input id="datepicker2" type="text" name="datto" placeholder="To" value="<?php if($datto){echo date('d F Y',strtotime($datto));}?>" class="input"></div>
	<input type="submit" value="Search" class="button2">
	<input type="submit" name="export" value="Export" class="button2">
	<input type="button" value="Reset" onclick="frm_submit()" class="button2">
	</div>
	<div class="orderform_panel">
		<h3>Order By:</h3> <select name="order" onchange="this.form.submit()">
		<option value="desc" <?php echo ($_REQUEST['order']=='desc')?'selected':'';?> >Desc</option>
		<option value="asc" <?php echo ($_REQUEST['order']=='asc')?'selected':'';?> >Asc</option>
		</select>
	</div>
</form>

<div class="applydata_container">
	<table cellspacing="0" cellpadding="0" class="table-w">
	<tr class="applydata_head">
			<th>ID</th><th>Created Date Time</th><th>Campaign Name</th><th>Lead Source</th><th>Lead Location</th><th>Name</th><th>Mobile</th><th>Email</th><th>treatments</th><th>Lead Notes</th><th>Lead Read</th><th>Call Response</th><th>PPC Campaign</th><th>PPC Source</th><th>PPC Keyword</th><th>IP Address </th><th>Region</th><th>Response</th>
		</tr>
		
	
<?php	
if($_REQUEST['uname']!=''){
	$whr.=" and lead_name like '%$uname%'";
}
if($_REQUEST['lead_mobile']!=''){
	$whr.=" and lead_mobile like '%$lead_mobile%'";
}
if($_REQUEST['email']!=''){
	$whr.=" and lead_email like '%$email%'";
}
if($datfrom!='' && $datto!=''){
	$whr.=" and lead_created_date_time >'".$datfrom. " 00:00:00' and lead_created_date_time<='".$datto. " 23:59:59'";
}	
if($_REQUEST['order']){
	$ordr = " order by lead_id ".$_REQUEST['order'];
}else{
	$ordr = " order by lead_id desc";
}
$targetpage = "lead_dashboard.php?datfrom=".$datfrom."&datto=".$datto."&uname=".$uname."&lead_mobile=".$lead_mobile."&email=".$email."&order=".$order; 
$limit = 20;
$page = $_GET['page'];
if($page)
$start = ($page - 1) * $limit; 
else
$start = 0;
global $wpdb;
$query1="select * from leads where 1 $whr $ordr ";
	
//echo "<pre>"; print_r($wpdb);
$rows= mysqli_query($con,$query1); 
//$total_rows = count($rows);
$total_rows = 100;
if ($page == 0) $page = 1;
$prev = $page - 1;					
$next = $page + 1;					
$lastpage = ceil($total_rows/$limit);	
$lpm1 = $lastpage - 1;
if($_REQUEST){$ff = $whr.$ordr;}
	$query="select * from leads where 1  $whr $ordr LIMIT $start, $limit";
	
	$sql=mysqli_query($con,$query);
	$k=1;
	foreach($sql as $row){
	echo "<tr><td>".$row['lead_id']."</td><td>".date('d F Y H:i:s',strtotime($row['lead_created_date_time']))."</td><td>".$row['lead_campaign_name']."</td><td>".$row['lead_source']."</td><td>".$row['lead_location']."</td><td>".$row['lead_name']."</td><td>".$row['lead_mobile']."</a></td><td>".$row['lead_email']."</td><td>".$row['treatments']."</td><td>".$row['lead_notes']."</td><td>".$row['lead_call_res']."</td><td>".$row['lead_ppc_campaign']."</td><td>".$row['lead_ppc_source']."</td><td>".$row['lead_ppc_keyword']."</td><td>".$row['lead_ip_address']."</td><td>".$row['lead_region']."</td><td>".$row['clc_response']."</td></tr>";
		$k++;
	}
	
		
if($k<1){
	echo "<tr><td colspan='14'><center><h1>Your search result is not found....</h1></center></td><td colspan='8'></td></tr>";
}
?>
</table>
<?php 
	$pagination = "";
	if($lastpage > 1){	
		$pagination .= "<div class=\"pagination\">";
		if ($page > 1) 
			$pagination.= "<a href=\"$targetpage&page=$prev\"><< previous</a><a href=\"$targetpage&page=1\"> First</a>";
		else
			$pagination.= "";
		if($page){$page = $page;}else{$page = 1;}
		$pagination .= '<span class="disabled current">Page '.$page.' Out of '.$lastpage.'</span>';
		
		//$pagination.= "<span class=\"disabled\"><< previous</span>";	
		/* if ($lastpage < 7 + ($adjacents * 2))	
		{	
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					$pagination.= "<span class=\"current\">$counter</span>";
				else
					$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
			}
		}
		elseif($lastpage > 5 + ($adjacents * 2))
		{
			if($page < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$pagination.= "";
						//$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage&page=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage&page=$lastpage\">$lastpage</a>";		
			}
			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
			{
				$pagination.= "<a href=\"$targetpage&page=1\">1</a>";
				$pagination.= "<a href=\"$targetpage&page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$pagination.= "";
						//$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage&page=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage&page=$lastpage\">$lastpage</a>";		
			}
			else
			{
				$pagination.= "<a href=\"$targetpage&page=1\">1</a>";
				$pagination.= "<a href=\"$targetpage&page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "";
						//$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
			}
		} */
		//next button
		if ($page != $lastpage) 
			$pagination.= "<a href=\"$targetpage&page=$lastpage\"> Last</a><a href=\"$targetpage&page=$next\">next >></a>";
		else
			$pagination.= "";
			//$pagination.= "<span class=\"disabled\">next >></span>";
		$pagination.= "</div>\n";		
	} 
	//echo $pagination;	
?>
</div>
<div class="pagination_applycontainer">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript">
$.noConflict();
  jQuery( function() {
	jQuery("#datepicker1").datepicker({dateFormat: 'd MM yy'});
	jQuery("#datepicker2").datepicker({dateFormat: 'd MM yy'});
  } );
  function frm_submit()
  {
  jQuery("input[type=text]").val("");
  jQuery('#apply_frm')[0].submit();
  }
  </script>
  </div>