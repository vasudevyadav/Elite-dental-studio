<?php
ob_start();
session_start();
// /**
//  * ClickToCall
//  * @Created By: Rohit (01 sep 2023)
//  * @Description: Handling Click to call Functionality
//  */


// class ClickToCall {
	
// 	// init vars
// 	var $connectionTimeOut = 5;
// 	var $executionTimeOut = 10;
	
// 	public function callToNumber($custNumber, $region , $campaign_department) {
// 			$prnval = $this->_get_Skill_DID($region,$campaign_department);
			
// 			global $lead_read_status;
// 		if (strtolower($region) == 'north') {
// 			$startTime = "09:00"; //24 hr format
// 			$endTime = "20:00"; //24 hr format
// 			$api_username = '';
// 			$api_key = '';
// 		} else {
// 			$startTime = "08:15"; //24 hr format
// 			$endTime = "20:45"; //24 hr format
// 			$api_username = '';  // for south region update on  29-07-2019
// 			$api_key = '';  // for south region update on  29-07-2019
// 		}
// 		global $is_rd_n_down;
// 		global $is_tata_n_down;
//         global $is_tata_s_down;
// 		global $is_rd_s_down;
// 		if(strtolower($region) == 'north' && ($is_rd_n_down != 1 || $is_tata_n_down != 1)){
// 		$pri_p1 = 0; // Reliance  
// 		$pri_p2 = 1; // Tata
// 		if($_POST['priority_pri']==1 && $is_tata_n_down != 1){$pri_p1 = 1; }
// 		if($is_rd_n_down == 1){
// 		$apiUrl = "http://api1.cloudagent.in/CAServices/AgentManualDial.php?username=".$api_username."&api_key=".$api_key."&uui=test&skill=".$prnval[$pri_p2]['skill']."&did=".$prnval[$pri_p2]['did']."";
// 	// echo strtolower($region). "<br>" .$apiUrl;
// 		}else{
// 		$apiUrl = "http://api1.cloudagent.in/CAServices/AgentManualDial.php?username=".$api_username."&api_key=".$api_key."&uui=test&skill=".$prnval[$pri_p1]['skill']."&did=".$prnval[$pri_p1]['did']."";
// 		//echo strtolower($region) . $apiUrl;
// 		}
// 		}
// 		if(strtolower($region) == 'south' && $is_rd_s_down == 1 && $is_tata_s_down == 1){
// 			$lead_read_status = "N";
// 			//echo "R South Down && T South Down" . '<br>';
// 		}
// 		if(strtolower($region) == 'north' && $is_rd_n_down == 1 && $is_tata_n_down == 1){
// 			$lead_read_status = "N";
// 			//echo "R North Down && T North Down". '<br>' ;
// 		}
// 		//echo $lead_read_status;
// 		if(strtolower($region) == 'south' && ($is_rd_s_down != 1 || $is_tata_s_down != 1) ){
// 		$pri_p1 = 0; // Tata 
// 		$pri_p2 = 1; // Reliance  
// 		if($_POST['priority_pri']==1 && $is_rd_s_down != 1){$pri_p1 = 1; }
// 		if($is_tata_s_down == 1 ){
// 		  $apiUrl = "http://api1.cloudagent.in/CAServices/AgentManualDial.php?username=".$api_username.   "&api_key=".$api_key."&uui=test&skill=".$prnval[$pri_p2]['skill']."&did=".$prnval[$pri_p2]['did']."";
	  
	  
// 	  // echo  strtolower($region) .$apiUrl . "<br>"; exit;
// 		}else{
// 		$apiUrl = "http://api1.cloudagent.in/CAServices/AgentManualDial.php?username=".$api_username."&api_key=".$api_key."&uui=test&skill=".$prnval[$pri_p1]['skill']."&did=".$prnval[$pri_p1]['did']."";
// 		//echo strtolower($region) . $apiUrl . "<br>"; exit;
// 		} 
// 		}
		
		
		
		
// 		if (extension_loaded('curl')) {
//             //Time Validity
// 			$date = new DateTime();
// 			$date->setTimezone(new DateTimeZone('Asia/Kolkata'));
// 			$currentTime = $date->format("H:i");
// 			if ((strtotime($currentTime) >= strtotime($startTime)) && (strtotime($currentTime) < strtotime($endTime))) {
// 				/**
// 				 * cURL extension is installed 
// 				 * call the method that call the service through cURL
// 				 */
// 				$curlUrl = "$apiUrl&customerNumber=$custNumber";
// 				$response = $this->_send_curl($curlUrl);
// 				$response = trim($response);
// 				$returnValue[1] = $response;
// 				//Handle the curl response
// 				$returnValue[0] = (($response == '<status>queued successfully</status>') ? TRUE : FALSE);
// 				if($returnValue[0]==FALSE && isset($prnval[1]['skill'])){
// 					$apiUrl = "http://api1.cloudagent.in/CAServices/AgentManualDial.php?username=".$api_username."&api_key=".$api_key."&uui=test&skill=".$prnval[1]['skill']."&did=".$prnval[1]['did']."";
// 					$curlUrl = "$apiUrl&customerNumber=$custNumber";
// 					$response = $this->_send_curl($curlUrl);
// 					$response = trim($response);
// 					if($returnValue[1]==''){$returnValue[1]='No Response';}
// 					$returnValue[1] = "1:".$returnValue[1].",2:".$response;
// 					//Handle the curl response
// 					$returnValue[0] = (($response == '<status>queued successfully</status>') ? TRUE : FALSE);
// 				}
// 			} else {
// 				$returnValue[0] = FALSE;
// 			}
//         } else {
// 			//Curl extension not enabled
// 			$returnValue[0] = FALSE;
//         }
//         /* Return the main response */
// 		return $returnValue;
//     }
	
// /*
// 	return skill and DID values
// 	*/
	
// 	private function _get_Skill_DID($region,$campaign_department){
// 			if (strtolower($region) == 'north') {
// 				switch($campaign_department){
// 					case 1: { //GoogleImplant 
// 						$prnval[0]['skill']	=	'RD_GoogleImplant';
// 						$prnval[0]['did']	=	'911139242108';
// 						$prnval[1]['skill']	=	'TD_GoogleImplant';
// 						$prnval[1]['did']	=	'911166451308';
// 						break;
// 						}
// 					case 2: { //GoogleBraces
// 						$prnval[0]['skill']	=	'RD_GoogleBraces';
// 						$prnval[0]['did']	=	'911139242109';
// 						$prnval[1]['skill']	=	'TD_GoogleBraces';
// 						$prnval[1]['did']	=	'911166451309';
// 						/* 
// 					    $prnval[0]['skill']	=	'T_cLoveMyBraces_Eng';
// 						$prnval[0]['did']	=	'911166451309';
// 						$prnval[1]['skill']	=	'R_cLoveMyBraces_Eng';
// 						$prnval[1]['did']	=	'911139242109';
// 						*/
// 						break;
// 						}
// 					case 3: { //GoogleGD  
// 						$prnval[0]['skill']	=	'RD_GoogleGD';
// 						$prnval[0]['did']	=	'911139242110';
// 						$prnval[1]['skill']	=	'TD_GoogleGD';
// 						$prnval[1]['did']	=	'911166451310'; 
// 						break;
// 						}
// 					case 4: { //FBDigital
// 						$prnval[0]['skill']	=	'RD_Facebook';
// 						$prnval[0]['did']	=	'911139242111';
// 					    $prnval[1]['skill']	=	'TD_Facebook';
// 						$prnval[1]['did']	=	'911166451311';
// 						break;
// 						}
// 					case 5: {  //website
// 						$prnval[0]['skill']	=	'R_WebCalls_Skill';
// 						$prnval[0]['did']	= 	'911139242129';
// 						$prnval[1]['skill']	=	'T_WebCalls_Skill';
// 						$prnval[1]['did']	=	'911166451329';
// 						break;
// 						}
// 					case 6: {  //GoogleDisplay
// 						$prnval[0]['skill']	=	'D_GoogleDisplay';
// 						$prnval[0]['did']	= 	'911139242143';
// 						$prnval[1]['skill']	=	'D_GoogleDisplay';
// 						$prnval[1]['did']	=	'911166451343';
// 						break;
// 						}
// 					case 7: {  //GoogleDisplay
// 						$prnval[0]['skill']	=	'RD_GoogleGD';
// 						$prnval[0]['did']	= 	'911139242110';
// 						$prnval[1]['skill']	=	'RD_GoogleGD';
// 						$prnval[1]['did']	=	'911139242110';
// 						break;
// 						}
// 					case 8: {  //SpotifyBranding
// 						$prnval[0]['skill']	=	'T_SpotifyBranding';
// 						$prnval[0]['did']	= 	'914066863226';
// 						$prnval[1]['skill']	=	'T_SpotifyBranding';
// 						$prnval[1]['did']	=	'914066863226';
// 						break;
// 						}
// 					case 9: {  //SpotifyBranding
// 						$prnval[0]['skill']	=	'R_DentistNearMe';
// 						$prnval[0]['did']	= 	'911139242157';
// 						$prnval[1]['skill']	=	'T_DentistNearMe';
// 						$prnval[1]['did']	=	'911166451357';
// 						break;
// 						}
// 					case 10: {  //Facebook Lead
// 						$prnval[0]['skill']	=	'FBLEADS';
// 						$prnval[0]['did']	= 	'911139242149';
// 						$prnval[1]['skill']	=	'FBLEADS';
// 						$prnval[1]['did']	=	'911166451349';
// 						break;
// 						}
// 					case 11: {  //Aligners
// 						$prnval[0]['skill']	=	'GoogleAligners';
// 						$prnval[0]['did']	= 	'911139242150';
// 						$prnval[1]['skill']	=	'GoogleAligners';
// 						$prnval[1]['did']	=	'911166451350';
// 						break;
// 						}	
// 					case 12: {  //Aligners
// 						$prnval[0]['skill']	=	'AffiliateAligner';
// 						$prnval[0]['did']	= 	'911139242125';
// 						$prnval[1]['skill']	=	'AffiliateAligner';
// 						$prnval[1]['did']	=	'911166451325';
// 						break;
// 						}

					   
// 					case 13: {  //Dentist Near Me

// 						$prnval[0]['skill']	=	'RD_GoogleGD';
// 						$prnval[0]['did']	= 	'911139242110';
// 						$prnval[1]['skill']	=	'RD_GoogleGD';
// 						$prnval[1]['did']	=	'911139242110';
// 						break;
// 						}					
// 				 default:{ //website
// 						$prnval[0]['skill']	=	'R_WebCalls_Skill';
// 						$prnval[0]['did']	= 	'911139242129';
// 						$prnval[1]['skill']	=	'T_WebCalls_Skill';
// 						$prnval[1]['did']	=	'911166451329';
// 					}
					
// 				}
// 			}else{
// 				switch($campaign_department){
// 					case 1: {
// 					    $prnval[0]['skill']	=	'TD_GoogleImplant';
// 						$prnval[0]['did']	=	'914069260019';
// 						$prnval[1]['skill']	=	'RD_GoogleImplant';
// 						$prnval[1]['did']	=	'914038245719';
						
// 						break;
// 						}
// 					case 2: {
// 						$prnval[0]['skill']	=	'TD_GoogleBraces';
// 						$prnval[0]['did']	=	'914069260020';
// 						$prnval[1]['skill']	=	'RD_GoogleBraces';
// 						$prnval[1]['did']	=	'914038245720';
// 						break;
// 						}
// 					case 3: {
// 					    $prnval[0]['skill']	=	'TD_GoogleGD';
// 						$prnval[0]['did']	=	'914069260021';
// 						$prnval[1]['skill']	=	'RD_GoogleGD';
// 						$prnval[1]['did']	=	'914038245721';
// 						break;
// 						}
// 					case 4: {
// 						$prnval[0]['skill']	=	'TD_Facebook';
// 						$prnval[0]['did']	=	'914069260022';
// 						$prnval[1]['skill']	=	'RD_Facebook';
// 						$prnval[1]['did']	=	'914038245722';
// 						break;
// 						}
// 					case 5: {
// 					    $prnval[0]['skill']	=	'T_WebCalls';
// 						$prnval[0]['did']	=	'914069260006';
// 						$prnval[1]['skill']	=	'R_Webcalls';
// 						$prnval[1]['did']	=	'914038245706';
// 						break;
// 						}
// 					case 6: {  //GoogleDisplay
// 						$prnval[0]['skill']	=	'D_GoogleDisplay';
// 						$prnval[0]['did']	= 	'914069260033';
// 						$prnval[1]['skill']	=	'D_GoogleDisplay';
// 						$prnval[1]['did']	=	'914038245733';
// 						break;
// 						}
// 					case 7: {  //GoogleDisplay
// 						$prnval[0]['skill']	=	'RD_GoogleGD';
// 						$prnval[0]['did']	= 	'911139242110';
// 						$prnval[1]['skill']	=	'RD_GoogleGD';
// 						$prnval[1]['did']	=	'911139242110';
// 						break;
// 						}
// 					case 8: {  //SpotifyBranding
// 						$prnval[0]['skill']	=	'T_SpotifyBranding';
// 						$prnval[0]['did']	= 	'914066863226';
// 						$prnval[1]['skill']	=	'T_SpotifyBranding';
// 						$prnval[1]['did']	=	'914066863226';
// 						break;
// 						}	
// 					case 9: {  //Dentistnearme
// 						$prnval[0]['skill']	=	'DentistNearMe';
// 						$prnval[0]['did']	= 	'914038245727';
// 						$prnval[1]['skill']	=	'DentistNearMe';
// 						$prnval[1]['did']	=	'914069260027';
// 						break;
// 						}
// 					case 10: {  //Facebook Lead
// 						$prnval[0]['skill']	=	'FBLEADS';
// 						$prnval[0]['did']	=	'914069260010';
// 						$prnval[1]['skill']	=	'FBLEADS';
// 						$prnval[1]['did']	= 	'914038245710';
						
// 						break;
// 						}
// 					case 11: {  //Aligners
// 						$prnval[0]['skill']	=	'GoogleAligners';
// 						$prnval[0]['did']	= 	'914038245728';
// 						$prnval[1]['skill']	=	'GoogleAligners';
// 						$prnval[1]['did']	=	'914069260028';
// 						break;
// 						}
// 					case 12: {  //Aligners
// 						$prnval[0]['skill']	=	'AffiliateAligner';
// 						$prnval[0]['did']	= 	'911139242125';
// 						$prnval[1]['skill']	=	'AffiliateAligner';
// 						$prnval[1]['did']	=	'911166451325';
// 						break;
// 						}
// 					case 13: {  //Dentist Near Me
// 						$prnval[0]['skill']	=	'TD_GoogleGD';
// 						$prnval[0]['did']	= 	'914066863221';
// 						$prnval[1]['skill']	=	'RD_GoogleGD';
// 						$prnval[1]['did']	=	'914030125821';
// 						break;
// 						}												
// 					default:{
// 					    $prnval[0]['skill']	=	'T_WebCalls';
// 						$prnval[0]['did']	=	'914069260006';
// 						$prnval[1]['skill']	=	'R_Webcalls';
// 						$prnval[1]['did']	=	'914038245706';
						
// 					}
					
// 				}
// 			}
// 		return $prnval;
		
// 	}

//     /**
//      * Call the service through cURL
//      * @access private
//      * @return string response
//      */
//     private function _send_curl($curlUrl) {
// 		/* Initiate a cURL session */
//         $ch = curl_init();

//         /* Set cURL variables */
//         curl_setopt($ch, CURLOPT_URL, $curlUrl);
// 		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->connectionTimeOut);
// 		curl_setopt($ch, CURLOPT_TIMEOUT, $this->executionTimeOut);
//         curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//         curl_setopt($ch, CURLOPT_POST, 0);
//         curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		
//         /* Send the request through cURL */
//         $response = curl_exec($ch);
		
//         /* End the cURL session */
//         curl_close($ch);

//         /* Return the server response */
//         return $response;
//     }
	
// }



$curl = curl_init();

$USER_ID = "24399444";
$TOKEN = "69pz3xZgqNOx0PUP6OUI";
$FROM = "9910119555";
$TO = mysqli_real_escape_string( $con, $phone );

curl_setopt_array($curl, array(
     CURLOPT_URL => 'https://s-ct3.sarv.com/v2/clickToCall/para?&user_id='.$USER_ID.'&token='.$TOKEN.'&from='.$FROM.'&to='.$TO,
     CURLOPT_RETURNTRANSFER => true,
     CURLOPT_ENCODING => "",
     CURLOPT_MAXREDIRS => 10,
     CURLOPT_TIMEOUT => 30,
     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
     CURLOPT_CUSTOMREQUEST => "POST",
     CURLOPT_POSTFIELDS => "",
     CURLOPT_HTTPHEADER => array(
     "cache-control: no-cache"
     ),
));


$response = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);


if ($err) {
     echo "cURL Error #:" . $err;
} else {
    echo $response;
}

?>