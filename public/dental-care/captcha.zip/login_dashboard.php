<?php
//ob_start();
session_start();
//require( dirname( __FILE__ ) . '/wp-load.php' );
$msg = "";
    include( 'connection.php' );

if($_POST['submit']=="Submit"){
	
	$username=$_POST['username'];
	$password=$_POST['password'];
	$psd = md5($password);
	$query="select * from lead_login where username='".$username."' and password='".$psd."' and status='1'";
	
	$sql= mysqli_query($con,$query);
	$sql= mysqli_fetch_array($sql);


	if(count($sql)>0){
	    
	$_SESSION["leadUser"]=$sql['username'];
	
    header("location: https://insight.exldentist.com/lead_dashboard.php");
	exit;
	}else{
		$msg = "Please enter valid username or password.";
	}
}
?>
<style>
.wrapper-b{background:#CA9345;position: absolute;top: 0;left: 0;width: 100%;height: 100%;overflow: hidden;}
.wrapper-b .form-b{max-width: 650px;margin: 0 auto;padding: 100px 0 0 0;text-align: center;position: relative;z-index: 2;}
.wrapper-b .form-b input, .wrapper-b .form-b input[type=password]{ -webkit-appearance: none; -moz-appearance: none; appearance: none; outline: 0; border: 1px solid rgba(255, 255, 255, 0.4); background-color: rgba(255, 255, 255, 0.2); width: 250px; border-radius: 3px; padding:8px; margin: 0 auto 15px auto; display: block; text-align: left; font-size: 14px; color: #fff; -webkit-transition-duration: 0.25s; transition-duration: 0.25s; font-weight: 300; resize:none; }
.wrapper-b .form-b input:hover { background-color: rgba(255, 255, 255, 0.4); }
.wrapper-b .form-b input:focus { background-color: white;  color: #000; }
.wrapper-b .form-b .button {-webkit-appearance: none;-moz-appearance: none;appearance: none;outline: 0;background: #aa5a93;border: 0;padding: 10px 15px;color: #ffffff;border-radius: 3px;width: 250px;cursor: pointer;font-size: 24px;-webkit-transition-duration: 0.25s;transition-duration: 0.25s;text-transform: uppercase;letter-spacing: 3px;font-weight: bold;text-align: center; }
.wrapper-b .form-b .button:hover { background: #000; }
.wrapper-b .form-b input::-webkit-input-placeholder { /* Chrome/Opera/Safari */
color: #ffffff;
}
.wrapper-b .form-b input::-moz-placeholder { /* Firefox 19+ */
color: #ffffff;
}
.wrapper-b .form-b input:-ms-input-placeholder { /* IE 10+ */
color: #ffffff;
}
.wrapper-b .form-b input:-moz-placeholder { /* Firefox 18- */
color: #ffffff;
}
.wrapper-b .form-b a{display: inline-block;padding: 10px 0px;margin-bottom: 15px;}
</style>


<div class="wrapper-b">
<div class="form-b">
    <a href="https://insight.exldentist.com/"><img src="https://insight.exldentist.com/images/logo.png"></a>
	<?php if($msg){ echo"<div style='color:#ffffff;font-size: 13px;'>".$msg."</div>";}?>
<form name="frm" method="post">
<input type="text" name="username" placeholder="Username">
<input type="password" name="password" placeholder="Password">
<input type="submit" name="submit" value="Submit" class="button">
</form>
</div>
</div>