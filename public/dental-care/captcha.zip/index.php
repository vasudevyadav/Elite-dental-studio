<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="css/responsive.css" />
        <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css" />
        <script src="https://kit.fontawesome.com/f02da0a219.js" crossorigin="anonymous"></script>
        <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css">
        <link rel="shortcut icon" href="images/favicon.png" />
        <title> Best Dentist in Gurgaon | Dental Implants | Cosmetic Dentistry</title>
        <meta id="description1" name="description" content="Specialised diagnosis, prevention, and treatment of oral diseases and conditions. Providing a range of services including routiatric dentistry, dental implants, root canal treatment, full mouth reconstruction, and more - www.exldentist.com" />
   
<meta name="google-site-verification" content="lCp4QmZM3lmkhjEVYiMHdVNfUsbhy4UMnz6317whU_Y" />

    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TK3P2PHV');</script>
<!-- End Google Tag Manager -->

<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '24659099283688943');
fbq('track', 'PageView');
</script>
<!-- End Meta Pixel Code -->

</head>
<body>

<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=24659099283688943&ev=PageView&noscript=1"
/></noscript>
    
       <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TK3P2PHV"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

        <!--=========== header area =========== -->
        <header class="header-area">
            <div class="container">
                <div class="header-inner">
                    <div class="top-lft-logo">
                        <a href="#"><img src="images/logo.png"></a>
                    </div>
                    <div class="appointment-header">
                        <div class="apt-contact">
                            

                            <p><img src="images/loc-ic.png" alt="call ic"> <a href="https://goo.gl/maps/wSmdjdwo332YGi4eA">DLF Phase IV, Gurugram</a></p>
                            <p><img src="images/call-ic.png" alt="call ic"> <a href="tel:8302155665">8302155665</a></p>
                            <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#myModalappointment" class="cmn-btn"><i class="fa-solid fa-phone"></i> instant call back</a>
                        </div>
                        <div class="book-btn">
                            <a href="#">Book An Appointment</a>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!--=========== end header area =========== -->

        <!-- ========= home banner area =======-->
        <section class="home-banner-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7">
                        <div class="banner-lft-cnt">
                            <h1>Your Picture Perfect<br> Smile Starts Here</h1>
                            <!-- <p>For A Confident, Long Lasting Smile</p> -->
                            <div class="slide-btn">
                                    <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#myModalappointment" class="cmn-btn tal-den">Contact Us Today</a>
<!--                                     <a href="#" class="cmn-btn dt-sol">Our Treatments</a> -->
                                </div>
                        </div>
                    </div>

                    <div class="col-lg-5">
                        <div class="book-appointment-out">
                            <div class="book-appointment">
                                <h2>Book an Appointment</h2>
 <form class="service-form"  method="POST"  id="clovecontact1" action="submit.php"
                                enctype="multipart/form-data" onSubmit="return checkForm();">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="input-group">
                                                <span class="input-group-text"><i class="fa fa-user" aria-hidden="true"></i></span>
                                                <input type="text" class="form-control" placeholder="Name" name="name" id="name" onKeyPress="return onlyAlphabets(event);" required  <?php if(isset($_session['yname']) && $_session['yname'] != ""){?>value = "<?php echo $_SESSION['yname']?>" <?php } $_SESSION['yname'] = ""?>>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="input-group">
                                                <span class="input-group-text"><i class="fa fa-phone" aria-hidden="true"></i></span>
                                                <input type="text" class="form-control" placeholder="Phone" name="phone" id="phone" onKeyPress="return isNumber(event);" maxlength="10"
                                        minlength="10" required <?php if(isset($_session['ytel']) && $_session['ytel'] != ""){?>value = "<?php echo $_SESSION['ytel']?>" <?php } $_SESSION['ytel'] = ""?>>
                                            </div>
                                        </div>
                                          <div class="col-lg-10 col-10">
                                              <div class="input_box captcha-inp">
                                                 <input type="text"  placeholder="Captcha" id="captcha_code" name="captcha_code" class="form-control" required="">
                                                 <span><img id="captcha_code1" src="/captcha/page_captcha_code1.php"   /></span>
                                                 <a href="#" class="captcha-load captcha_refresh capLoad" onClick="refreshCaptcha1();" id="refresh_captcha"><img src="images/catcha-load.png" alt="captcha"></a>
                                                 
                                              </div>
                                          </div>
                                          <?php 
		  if(isset($_SESSION['error_issue']) && $_SESSION['error_issue'] != ""){
		  ?>
		  <p><?php echo $_SESSION['error_issue']; $_SESSION['error_issue'] = "";?></p>
		  <?php
		  }
		  ?>
		 <?php 
		  if(isset($_SESSION['captcha_issue']) && $_SESSION['captcha_issue'] != ""){
		  ?>
		  <p><?php echo $_SESSION['captcha_issue']; $_SESSION['captcha_issue'] = "";?></p>
		  <?php
		  }
		  ?>

                                        <!--<div class="form-check mb-3">-->
                                        <!--    <label class="form-check-label">-->
                                        <!--      <input class="form-check-input" type="checkbox" name="disclaimer" required> I declare that the information provided is correct. I would like to receive communication about Dental services.-->
                                        <!--    </label>-->
                                        <!--</div>-->
                                    <input type="hidden" name="url" value="<?php echo $_SERVER['REQUEST_URI']; ?>"> 
                                    <input type="hidden" name="utm_campaign" value="<?php echo $_GET['utm_campaign']; ?>">
                                    <input type="hidden" name="utm_source" value="<?php echo $_GET['utm_source']; ?>">
                                    <input type="hidden" name="utm_medium" value="<?php echo $_GET['utm_medium']; ?>">
                                    <input type="hidden" name="utm_term" value="<?php echo $_GET['utm_term']; ?>">
                                    </div>
                                    <div class="form-sbmt-btn text-center">
                                        <button type="submit" class="cmn-btn" id="callme_button">Submit</button>
                                    </div>
                                    <div class="after-smbt-p">
                                        <p>By clicking Submit you agree to be contacted by Exldentist over Phone or SMS/WhatsApp/Email.</p>
                                    </div>

                                </form>                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </section>
        <!-- ========= end home banner area =======-->
                <!--========= Dental Treatments area ========-->
        <section class="dental-treatments-area">
            <div class="container">
                <div class="dental-heading" data-aos="fade-up" data-aos-duration="1000">
                    <div class="heading">
                        <h2>The Array of <br>Dental Treatments</h2>
                        <hr />
                        <p>We are the experts in dental treatments and<br> offer a complete range of dental solutions for <br>all your dental concerns.</p>
                    </div>
                    <div class="dnt-btn desk-view">
                        <a href="#" class="cmn-btn">Book An Appointment</a>
                    </div>
                </div>
            </div>
            <div class="dental-treatments-slide" data-aos="fade-up" data-aos-duration="1000">
                <div class="container">
                    <div class="col-lg-12">
                        <div class="owl-carousel dental-treat-owl">
                            <div class="item">
                                <div class="dental-treat-bx">
                                    <div class="dent-treat-cin">
                                        <img src="images/full-mouth.jpg" class="img-fluid" alt="img-fluid" />
                                    </div>
                                    <div class="dent-treat-cnt">
                                        <h3>Full Mouth Rehabilitation</h3>
                                        <p>Rediscover a functional and beautiful smile through our comprehensive full mouth rehabilitation. Our expert team combines advanced techniques to restore your oral health, ensuring comfort and aesthetics.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="dental-treat-bx">
                                    <div class="dent-treat-cin">
                                        <img src="images/dental-sol-img-2.jpg" class="img-fluid" alt="img-fluid" />
                                    </div>
                                    <div class="dent-treat-cnt">
                                        <h3>Dental Implants</h3>
                                        <p>Regain the confidence to smile naturally with our state-of-the-art dental implant solutions. Our skilled professionals use cutting-edge technology to provide you with secure and lasting tooth replacements.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="dental-treat-bx">
                                    <div class="dent-treat-cin">
                                        <img src="images/veneers-3.jpeg" class="img-fluid" alt="img-fluid" />
                                    </div>
                                    <div class="dent-treat-cnt">
                                        <h3>Veneers / Crowns / Inlays / Onlays</h3>
                                        <p>Transform your smile with precision-crafted veneers, crowns, inlays, and onlays. Our artistic approach enhances the appearance and strength of your teeth, delivering results that dazzle.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="dental-treat-bx">
                                    <div class="dent-treat-cin">
                                        <img src="images/gum.jpg" class="img-fluid" alt="img-fluid" />
                                    </div>
                                    <div class="dent-treat-cnt">
                                        <h3>Gum Treatment / Scaling / Depigmentation</h3>
                                        <p>Keep your gum healthy to its optimum through our specialized treatments, including gentle scaling and depigmentation. Experience improved oral hygiene and enhanced smiles.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="item">
                                <div class="dental-treat-bx">
                                    <div class="dent-treat-cin">
                                        <img src="images/rct-img.jpg" class="img-fluid" alt="img-fluid" />
                                    </div>
                                    <div class="dent-treat-cnt">
                                        <h3>Fillings / RCT</h3>
                                        <p>Say goodbye to discomfort with our expertly performed fillings and root canal treatments. Our gentle approach alleviates pain and restores the health and integrity of your teeth.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="item">
                                <div class="dental-treat-bx">
                                    <div class="dent-treat-cin">
                                        <img src="images/aligners-1.jpg" class="img-fluid" alt="img-fluid" />
                                    </div>
                                    <div class="dent-treat-cnt">
                                        <h3>Invisalign / Braces</h3>
                                        <p>Achieve the smile you've always wanted with Invisalign or braces. Being a trusted Dental Clinic In DLF Phase 4, our orthodontic solutions focus on straightening your teeth giving you a confident smile.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="dental-treat-bx">
                                    <div class="dent-treat-cin">
                                        <img src="images/dentures-1.jpeg" class="img-fluid" alt="img-fluid" />
                                    </div>
                                    <div class="dent-treat-cnt">
                                        <h3>Fixed and Removable Dentures</h3>
                                        <p>Regain your ability to chew and speak with ease through our customized fixed and removable dentures. Experience comfort and functionality while enjoying a renewed quality of life.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="dental-treat-bx">
                                    <div class="dent-treat-cin">
                                        <img src="images/kids-1.jpeg" class="img-fluid" alt="img-fluid" />
                                    </div>
                                    <div class="dent-treat-cnt">
                                        <h3>Child Dentistry</h3>
                                        <p>Nurturing young smiles and building better smiles is our priority. Our child-friendly approach creates positive dental experiences, setting the foundation for a lifetime of optimal oral health.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="dental-treat-bx">
                                    <div class="dent-treat-cin">
                                        <img src="images/3-min.jpeg" class="img-fluid" alt="img-fluid" />
                                    </div>
                                    <div class="dent-treat-cnt">
                                        <h3>Laser Dentistry</h3>
                                        <p>Experience the comfort of minimally invasive treatments with our highly advanced, cutting-edge laser dentistry treatments that provide faster healing, reduced discomfort.</p>
                                    </div>
                                </div>
                            </div>


                        </div>
                        <div class="dnt-btn mob-view text-center mt-4">
                            <a href="#" class="cmn-btn">Book An Appointment</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--========= end Dental Treatments area ========-->
        <!-- ========== about area ==========-->
        <section class="about-area">
            <div class="container">
                <div class="about-inner">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <div class="about-lft-img">
                                <img src="images/about-lft-img.png" alt="" class="img-fluid">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="abou-rgt-cnt">
                                <div class="heading">
                                    <h2>About <br>EXL Dentist</h2>
                                    <p>
                                        At EXLDentist, we're a dedicated team of dental professionals committed to excellence in all specialties. From maintaining general oral health to providing specialized dental treatments, we offer a comprehensive range of advanced dental services tailored to patients of all ages. Our principles:<br>
                                        <b>Excellence:</b> We utilize cutting-edge techniques for the best results.<br>
                                        <b>Xenial Environment:</b> Our warm and welcoming atmosphere puts you at ease.<br>
                                        <b>Lasting Results, Lifelong Relationship:</b> We aim for enduring results and nurturing trust-based, long-term relationships.

                                    </p>
                                    <hr>
                                </div>
                                <div class="row banner_uspes">
                                  <div class="col-3">
                                    <div class="usp_box">
                                        <img src="images/about-ic-1.png" alt="">
                                      <h2 class="counter-count">2800</h2>
                                      <span>+</span>
                                      <p>Dental Fillings</p>
                                    </div>
                                  </div>
                                  <div class="col-3">
                                    <div class="usp_box">
                                      <img src="images/about-ic-2.png" alt="">
                                      <h2 class="counter-count">1200</h2>
                                      <span>+</span>
                                      <p>Tooth Extraction</p>
                                    </div>
                                  </div>
                                  <div class="col-3">
                                    <div class="usp_box">
                                      <img src="images/about-ic-3.png" alt="">
                                      <h2 class="counter-count">3</h2>
                                      <span>K+</span>
                                      <p>Root Canal</p>
                                    </div>
                                  </div>
                                  <div class="col-3">
                                    <div class="usp_box">
                                      <img src="images/about-ic-4.png" alt="">
                                      <h2 class="counter-count">2100</h2>
                                      <span>+</span>
                                      <p>Implants Placed</p>
                                    </div>
                                  </div>
                                </div>

                            </div>
                        </div>
                        
                    </div>

                </div>
            </div>
        </section>
        <!-- ========== end about area ==========-->
        <!-- ======== image gallery =========-->
        <section class="gallery-area gallery-inter-area desk-view">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="gallery-img left-gallery-img">
                            <img src="images/gallery-2.png" alt="" class="img-fluid">
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="row">
                            <div class="col-lg-4 col-md-6">
                                <div class="gallery-img">
                                    <img src="images/gallery-1.png" alt="" class="img-fluid">
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="gallery-img">
                                    <img src="images/gallery-3.png" alt="" class="img-fluid">
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="gallery-img">
                                    <img src="images/gallery-4.png" alt="" class="img-fluid">
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="gallery-img">
                                    <img src="images/gallery-5.png" alt="" class="img-fluid">
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="gallery-img">
                                    <img src="images/gallery-6.png" alt="" class="img-fluid">
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="gallery-img">
                                    <img src="images/gallery-7.png" alt="" class="img-fluid">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="gallery-area gallery-inter-area mob-view">
            <div class="container">
                <div class="gallery-inter-slide">
                    <div class="owl-carousel gallery-inter-owl">
                      <div class="item">
                          <div class="gallery-img">
                              <img src="images/gallery-2.png" alt="" class="img-fluid">
                          </div>
                      </div>
                        <div class="item">
                            <div class="gallery-img">
                                <img src="images/gallery-1.png" alt="" class="img-fluid">
                            </div>
                        </div>
                        <div class="item">
                            <div class="gallery-img">
                                <img src="images/gallery-3.png" alt="" class="img-fluid">
                            </div>
                        </div>
                        <div class="item">
                            <div class="gallery-img">
                                <img src="images/gallery-4.png" alt="" class="img-fluid">
                            </div>
                        </div>
                        <div class="item">
                            <div class="gallery-img">
                                <img src="images/gallery-5.png" alt="" class="img-fluid">
                            </div>
                        </div>
                        <div class="item">
                            <div class="gallery-img">
                                <img src="images/gallery-6.png" alt="" class="img-fluid">
                            </div>
                        </div>
                        <div class="item">
                            <div class="gallery-img">
                                <img src="images/gallery-7.png" alt="" class="img-fluid">
                            </div>
                        </div>

                  </div>
                </div>
            </div>
        </section>

        <!-- ======== end image gallery =========-->
        <!-- ======== team of doctor =========-->
        <section class="team-of-doctor">
          <div class="container">
            <div class="heading text-center">
                <h2>Team of Doctors</h2>
                <hr style="margin: 18px auto 20px;">
            </div>
            
            <div class="row justify-content-center">
                <div class="col-lg-3 col-md-6">
                    <div class="dental-team-bx">
                        <img src="images/team-1.png" class="img-fluid" alt="team 1">
                        <h4>Dr Priyanka Kumar </h4>
                        <p>BDS, MDS, FAD, DSD</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="dental-team-bx">
                        <img src="images/team-2.png" class="img-fluid" alt="team 2">
                        <h4>Dr. Manreet Sidhu </h4>
                        <p>BDS, MDS, MOrth RCSEd(U.K) </p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="dental-team-bx">
                        <img src="images/team-3.png" class="img-fluid" alt="team 3">
                        <h4>Dr. Chandravir Singh </h4>
                        <p>BDS, MDS (Oral and Maxillofacial Implant surgeon) </p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="dental-team-bx">
                        <img src="images/team-4.png" class="img-fluid" alt="team 4">
                        <h4>Dr. Prabha Rao</h4>
                        <p>BDS</p>
                    </div>
                </div>
            </div>  

          </div>  
        </section>
        <!-- ======== team of doctor =========-->

        <!-- =========== clinic near you ===========-->
        <section class="clinic-near-you">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-7">
                        <div class="find-dental-near-bx">
                            <div class="heading">
                                <h2>Find a Dental Clinic Near You</h2>
                                <hr>
                            </div>
                            <div class="clinic-map-bx">
                                <!-- <div class="select-view-btn">
                                    <form action="" method="post" onsubmit="" id="loc_form">
                                        <div class="input_box">
                                            <select id="select-loc" class="form-control form-select">
                                              <option>Select Your Clinic</option>
                                              <option value="">Mansarover</option>
                                              <option value="">Malviya Nagar</option>
                                              <option value="">Vashali</option>
                                            </select>
                                        </div>
                                        <div class="dnt-treat-btn">
                                            <button class="cmn-btn">View Branch</button>
                                        </div>
                                    </form>
                                </div> -->
                                <div class="row">
                                    <div class="col-lg-7">
                                        <div class="loc-contact-info">
                                            <h3>DLF Phase IV, Gurugram</h3>
                                            <div class="loc-li-info clinic-address">
                                                <div class="info-add">
                                                    <p>Address: 7702, DLF Phase IV, Gurugram, Haryana 122029</p>
                                                </div>
                                            </div>
                                            <div class="clinic-call">
                                                <div class="loc-li-info">
                                                    <div class="info-ic">
                                                        <i class="fa-solid fa-phone"></i>
                                                    </div>
                                                    <div class="info-add">
                                                        <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#myModalappointment">instant call back</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="clinic-direc-btn">
                                                <a href="https://goo.gl/maps/i27a5Wa8T277G5EV9" class="cmn-btn cmn-dir">Get Direction</a>
                                                <a href="#" class="cmn-btn cmn-det">View Details</a>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="col-lg-5">
                                        <div class="loc-map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3507.6438046151425!2d77.087592!3d28.460152!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d19283826fe83%3A0xc0c63420d28052ea!2sEXL%20Dentist%20-%20Dental%20Clinic%20in%20Gurgaon%20%7C%20Dental%20Implants%7C%20Root%20Canal%20%7C%20Aligners%20%7C%20RCT%20%7C%20Braces%20%7C%20Smile%20Makeover%20in%20Gurgaon!5e0!3m2!1sen!2sin!4v1693740896216!5m2!1sen!2sin" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-5">
                        <div class="book-appointment-out">
                            <div class="book-appointment">
                                <h2>Book an Appointment</h2>
 <form class="service-form"  method="POST"  id="clovecontact3" action="submit3.php"
                                enctype="multipart/form-data" onSubmit="return checkForm2();">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="input-group">
                                                <span class="input-group-text"><i class="fa fa-user" aria-hidden="true"></i></span>
                                                <input type="text" class="form-control" placeholder="Name" name="name" id="bname" onKeyPress="return onlyAlphabets(event);" required  <?php if(isset($_session['yname']) && $_session['yname'] != ""){?>value = "<?php echo $_SESSION['yname']?>" <?php } $_SESSION['yname'] = ""?>>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="input-group">
                                                <span class="input-group-text"><i class="fa fa-phone" aria-hidden="true"></i></span>
                                                <input type="text" class="form-control" placeholder="Phone" name="phone" id="bphone" onKeyPress="return isNumber(event);" maxlength="10"
                                        minlength="10" required <?php if(isset($_session['ytel']) && $_session['ytel'] != ""){?>value = "<?php echo $_SESSION['ytel']?>" <?php } $_SESSION['ytel'] = ""?>>
                                            </div>
                                        </div>
                                          <div class="col-lg-10 col-10">
                                              <div class="input_box captcha-inp">
                                                 <input type="text"  placeholder="Captcha" id="bcaptcha_code" name="captcha_code" class="form-control" required="">
                                                 <span><img id="captcha_code2" src="/captcha/page_captcha_code2.php"   /></span>
                                                 <a href="javascript:void(0)" class="captcha-load captcha_refresh capLoad" onClick="refreshCaptcha2();" id="brefresh_captcha"><img src="images/catcha-load.png" alt="captcha"></a>
                                                 
                                              </div>
                                          </div>
                                          <?php 
		  if(isset($_SESSION['error_issue']) && $_SESSION['error_issue'] != ""){
		  ?>
		  <p><?php echo $_SESSION['error_issue']; $_SESSION['error_issue'] = "";?></p>
		  <?php
		  }
		  ?>
		 <?php 
		  if(isset($_SESSION['captcha_issue']) && $_SESSION['captcha_issue'] != ""){
		  ?>
		  <p><?php echo $_SESSION['captcha_issue']; $_SESSION['captcha_issue'] = "";?></p>
		  <?php
		  }
		  ?>

                                        <!--<div class="form-check mb-3">-->
                                        <!--    <label class="form-check-label">-->
                                        <!--      <input class="form-check-input" type="checkbox" name="disclaimer" required> I declare that the information provided is correct. I would like to receive communication about Dental services.-->
                                        <!--    </label>-->
                                        <!--</div>-->
                                    <input type="hidden" name="url" value="<?php echo $_SERVER['REQUEST_URI']; ?>"> 
                                    <input type="hidden" name="utm_campaign" value="<?php echo $_GET['utm_campaign']; ?>">
                                    <input type="hidden" name="utm_source" value="<?php echo $_GET['utm_source']; ?>">
                                    <input type="hidden" name="utm_medium" value="<?php echo $_GET['utm_medium']; ?>">
                                    <input type="hidden" name="utm_term" value="<?php echo $_GET['utm_term']; ?>">
                                    </div>
                                    <div class="form-sbmt-btn text-center">
                                        <button type="submit" class="cmn-btn" id="callme_button">Submit</button>
                                    </div>
                                    <div class="after-smbt-p">
                                        <p>By clicking Submit you agree to be contacted by Perfect Smile over Phone or SMS/WhatsApp/Email.</p>
                                    </div>

                                </form>


                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </section>
        <!-- =========== end clinic near you ===========-->

        <!-- ========== why choose us ===========-->
        <section class="why-choose-area">
            <div class="container">
                <div class="heading text-center">
                    <h2>Why Choose Us?</h2>
                    <hr style="margin: 18px auto 20px;">
                    <p>We understand that choosing a dental provider is an important decision that impacts your health<br> and well-being. Your search for ‘best dentist near me’ ends with us. Here's why:</p>
                </div>

                <div class="row why-choose-row align-items-center">
                    <div class="col-lg-6">
                        <div class="row">
                             <div class="col-lg-6 col-6">
                                 <div class="why-ic-bx">
                                     <img src="images/why-ic-1.png" alt="" class="img-fluid">
                                     <p>Comprehensive <br>Expertise</p>
                                 </div>
                             </div>
                             <div class="col-lg-6 col-6">
                                 <div class="why-ic-bx">
                                     <img src="images/why-ic-2.png" alt="" class="img-fluid">
                                     <p>Patient-Centric<br> Approach</p>
                                 </div>
                             </div>
                             <div class="col-lg-6 col-6">
                                 <div class="why-ic-bx">
                                     <img src="images/why-ic-3.png" alt="" class="img-fluid">
                                     <p>Cutting-Edge <br>Technology</p>
                                 </div>
                             </div>
                             <div class="col-lg-6 col-6">
                                 <div class="why-ic-bx">
                                     <img src="images/why-ic-4.png" alt="" class="img-fluid">
                                     <p>Holistic<br> Well-being</p>
                                 </div>
                             </div>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="why-rgt-img">
                            <img src="images/why-choose-img.png" alt="" class="img-fluid">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- ========== end why choose us ===========-->
        <!-- ========= testimonail area ==========-->
       <section class="testimonials">
            <div class="testi-bg">
                <div class="container">
                    <div class="heading text-center">
                        <h2>Make an Appointment</h2>
                        <hr style="margin: 18px auto 20px;">
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-10">
                        <div class="apoint-table table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Opening Hours</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Monday - Saturday </td>
                                        <td>10:00 AM - 07:00 PM</td>
                                    </tr>
                                    <tr>
                                        <td>Sunday</td>
                                        <td>Sunday only on appointment</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="btn-center text-center">
                    <a href="#" class="cmn-btn">Book An Appointment</a>
                </div>


            </div>

            <div class="testi-slide">
                <div class="container">
                    <div class="owl-carousel testi-owl">
                        <div class="item">
                            <div class="testimonials-bx">
                                <div class="testi-author">
                                    <img src="images/testi-aut-1.png" alt="" class="img-fluid">
                                </div>
                                <div class="testimonials-cnt">
                                    <img src="images/quote.png" alt="">
                                    <p>Top class hygiene, Courteous staff and above all experienced Administrator  and Dentist.. Dr. PRIYANKA. Had a wonderful experience during my visit for consultation , came back thoroughly satisfied. I strongly recommend to visit " Exl Dentist" for any dental problems</p>
                                    <hr>
                                    <h6>S K MALHOTRA, EX- SDM</h6>
                                </div>

                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonials-bx">
                                <div class="testi-author">
                                    <img src="images/testi-aut-1.png" alt="" class="img-fluid">
                                </div>
                                <div class="testimonials-cnt">
                                    <img src="images/quote.png" alt="">
                                    <p>I am Fully contended with the kind of service provided at EXL. Dr. Priyanka makes you feel
                                comfortable and communicates quite well before the procedure itself. I came here for cleaning and I am confirmed that I
                                will come for my wisdom tooth extraction, here only. Thank you so much for the best and comfortable treatment
                                provided.</p>
                                    <hr>
                                    <h6>Prerna Bhatia </h6>
                                </div>

                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonials-bx">
                                <div class="testi-author">
                                    <img src="images/testi-aut-1.png" alt="" class="img-fluid">
                                </div>
                                <div class="testimonials-cnt">
                                    <img src="images/quote.png" alt="">
                                    <p>I visited the clinic two days back. RCT done  there. Thanku so much Dr. Priyanka kumar. I would highly recommend this clinic to all my friends and relatives.</p>
                                    <hr>
                                    <h6>Prabha Rao</h6>
                                </div>

                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonials-bx">
                                <div class="testi-author">
                                    <img src="images/testi-aut-1.png" alt="" class="img-fluid">
                                </div>
                                <div class="testimonials-cnt">
                                    <img src="images/quote.png" alt="">
                                    <p>It's my family go to place for all dental issues. Extremely clean and hygienic place. The staff is very cooperative & polite, plus the dentists are excellent. Special shoutout to Dr. Priyanka kumar for being super helpful and nice always..</p>
                                    <hr>
                                    <h6>Ms. Smriti sahu</h6>
                                </div>
                            </div>
                        </div>


                    </div>
                    
                </div>
            </div>
       </section>
       <!-- ========= end testimonail area ==========-->

        <!-- ======== it works area ==========-->
        <!-- <section class="it-works-area">
            <div class="container">
                <div class="heading text-center">
                    <h2>It works, <br>Say our Patients</h2>
                    <hr style="margin: 18px auto 20px;">
                </div>

                <div class="it-works-slide">
                    <div class="owl-carousel work-owl">
                        <div class="item"> 
                             <div class="works-image">          
                                 <img src="images/1.jpg" alt="">   
                             </div>
                        </div>
                        <div class="item"> 
                            <div class="works-image">          
                                 <img src="images/2.jpg" alt="">   
                             </div>
                        </div>
                        <div class="item"> 
                            <div class="works-image">          
                                 <img src="images/3.jpg" alt="">   
                             </div>
                        </div>
                        <div class="item"> 
                            <div class="works-image">          
                                 <img src="images/5.jpg" alt="">   
                             </div>
                        </div>  
                        <div class="item"> 
                            <div class="works-image">          
                                 <img src="images/6.jpg" alt="">   
                             </div>
                        </div>                    
                    </div>
                </div>

            </div>
        </section> -->
        <!-- ======== end it works area ==========-->

       <!-- ========== faq area  =========-->
        <section class="faq-about-plan-area faq-inner" data-aos="fade-up" data-aos-duration="1000">
            <div class="pos-about-girl">
                <img src="images/faq-side.png" alt="">
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="blog-faq">
                            <div class="heading">
                                <h2>Frequently<br> Asked Questions</h2>
                            </div>
                            <div class="accordion" id="accordionExample">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingOne">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                            1. Can a dentist near me help in the case of severe tooth pain?
                                        </button>
                                    </h2>
                                    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            Yes, if you visit a dentist nearby, they can help alleviate the pain by treating the teeth based on the condition of the teeth. If you are experiencing any dental problems or pain, you can get in touch with us right away at  +91 - 9910119555, 0124- 4276354
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingTwo">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                            2. How often should I have a dental check-up?
                                        </button>
                                    </h2>
                                    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            We recommend regular dental check-ups every six months. These visits allow us to monitor your oral health, address any emerging issues, and perform professional cleanings to maintain your smile's brilliance.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingThree">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                            3.  What is the difference between veneers and crowns?
                                        </button>
                                    </h2>
                                    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            Veneers are thin shells placed over the front surface of teeth to improve appearance, while crowns cover the entire tooth for both aesthetic and structural enhancement. Our experts will guide you in choosing the best option for your needs.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingfour">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapsefour" aria-expanded="false" aria-controls="collapsefour">
                                            4. Can I whiten my teeth if I have sensitive teeth?           
                                        </button>
                                    </h2>
                                    <div id="collapsefour" class="accordion-collapse collapse" aria-labelledby="headingfour" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            Yes, you can still whiten your teeth if you have sensitivity. We offer various teeth whitening options, including those designed for sensitive teeth. Our team will recommend the most suitable solution for you.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingfive">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapsefive" aria-expanded="false" aria-controls="collapsefive">
                                            5. What is the cost of RCT at your Dental Clinic In DLF Phase 4?
                                        </button>
                                    </h2>
                                    <div id="collapsefive" class="accordion-collapse collapse" aria-labelledby="headingfive" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            The cost of a Root Canal Treatment (RCT) can vary based on factors such as the tooth's location, the complexity of the case, and any additional procedures required. We recommend scheduling a consultation with our experienced dental team at our DLF Phase 4 clinic.
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                            <div class="wd-nbn">
                                <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#myModalappointment" class="talk-to-cd">
                                    <div class="t-inner">
                                        <div class="img-box">
                                            <img src="images/talk_to_icon.png">
                                        </div>
                                        <div class="t-info">
                                            <h2>instant call back</h2>
                                        </div>
                                    </div>
                                </a>
                            </div>

                </div>
            </div>
        </section>
        <!-- ========== end faq area  =========-->

        <footer class="footer-area">
            <div class="container">
                <div class="bottom-footer">
                    <div class="inner-foot-botm">
                        <div class="foot-prcy">
                            <p>Copyright © 2023 Dental. All Rights Reserved</p>
                        </div>
                        <div class="foot-prcy">
                            <p>Design &amp; Developed By:<a href="https://www.reinventdigital.com/">Reinvent Digital </a></p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>

                <!-- ====== mobile call strip  ======-->
        <div class="action_btns_bottom">
          <div class="action_inner">
            <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#myModalappointment" class="phn-btn" target="_blank"><i class="fa fa-phone" aria-hidden="true"></i> instant call back</a> 
            <a href="#" class="phn-apoint"><i class="fa-solid fa-calendar-check"></i> Book An Appointment</a>
          </div>
        </div>
        <!-- ==== end mobile call strip  ====-->

        <!--========== book appointment form popup ============= -->
        <div class="modal dr-video-pop appointment-pop fade" id="myModalappointment" tabindex="-1" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                <div class="call-back-area book-appointment">
                    <div class="heading text-center mb-4">
                        <h2>Instant call back</h2>
                    </div>
                     <div class=" appointment-form">

<form class="service-form" method="POST"  id="clovecontact1" action="submit2.php"
                                enctype="multipart/form-data" onSubmit="return checkForm1();" >
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fa fa-user" aria-hidden="true"></i></span>
                                        <input type="text" class="form-control" placeholder="Name" name="name" id="popupname">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fa fa-phone" aria-hidden="true"></i></span>
                                        <input type="text" class="form-control" placeholder="Phone" name="phone" id="popupphone">
                                    </div>
                                </div>

                                    <input type="hidden" name="url" value="<?php echo $_SERVER['REQUEST_URI']; ?>"> 
                                    <input type="hidden" name="utm_campaign" value="<?php echo $_GET['utm_campaign']; ?>">
                                    <input type="hidden" name="utm_source" value="<?php echo $_GET['utm_source']; ?>">
                                    <input type="hidden" name="utm_medium" value="<?php echo $_GET['utm_medium']; ?>">
                                    <input type="hidden" name="utm_term" value="<?php echo $_GET['utm_term']; ?>">
                                    </div>
                                    <div class="form-sbmt-btn text-center">
                                        <button type="submit" class="cmn-btn" id="callme_button1">Submit</button>
                            </div>
                        </form>
                     </div>
               
                </div>
            </div>
          </div>
        </div>

        <!--========== book appointment form popup ============= -->

        <script src="js/jquery.min.js"></script>
        <script src="js/popper.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/style.js"></script>
        <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
        <script>
          AOS.init();
        </script>
        
        <script>
     function refreshCaptcha1() {
jQuery("#captcha_code1").attr('src','/captcha/page_captcha_code1.php?var='+new Date().getTime());
}
function refreshCaptcha2() {
jQuery("#captcha_code2").attr('src','/captcha/page_captcha_code2.php?var='+new Date().getTime());
}
            function onlyAlphabets(e, t) {
	return (e.charCode > 64 && e.charCode < 91) || (e.charCode > 96 && e.charCode < 123) || e.charCode == 32;   
}
       function isNumber(evt) {
	evt = (evt) ? evt : window.event;
	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57)) {
		return false;
	}
	return true;
}    
//name validation function
function IsAlpha( name ) {
	var regex = /^([a-zA-Z _']*)$/;
	return regex.test( name );
}
//phone number validation
function validateNumber( phone ) {
	if ( phone.length >= 10 ) {
		var RE = /^\d*[0-9](|.\d*[0-9]|,\d*[0-9])?$/;
		return ( RE.test( phone ) );
	} else {
		return false;
	}
}

function checkForm(){
	var error = true;
	var name = $('#name').val();
	var phone = $('#phone').val();
	var captcha = $("#captcha_code").val();
	if(name == ""){
		error = false;
		$("#name").addClass('error');
	}else{
		nmr = IsAlpha(name);
		if(nmr == true){
			$("#name").removeClass('error');
		}else{
			error = false;
			$("#name").addClass('error');
		}
	}
	if(phone == "" ||  phone.length < 10){
		error = false;
		$("#phone").addClass('error');
	}else{
		vnr = validateNumber(phone)
		if(vnr == true){
			$("#phone").removeClass('error');
		}else{
			error = false;
			$("#phone").addClass('error');
		}
	}
	
	if(captcha == ""){
		error = false;
		$("#captcha_code").addClass('error');
	}else{
		$("#captcha_code").removeClass('error');
	}
	//alert(error);
	if(error == false){
		return error;
	}else{
		
		$("#callme_button").html('Please Wait...');
		$("#callme_button").attr('disabled','disabled');
		
	}
}
function checkForm1(){
	var error = true;
	var name = $('#popupname').val();
	var phone = $('#popupphone').val();
	if(name == ""){
		error = false;
		$("#popupname").addClass('error');
	}else{
		nmr = IsAlpha(name);
		if(nmr == true){
			$("#popupname").removeClass('error');
		}else{
			error = false;
			$("#popupname").addClass('error');
		}
	}
	if(phone == "" ||  phone.length < 10){
		error = false;
		$("#popupphone").addClass('error');
	}else{
		vnr = validateNumber(phone)
		if(vnr == true){
			$("#popupphone").removeClass('error');
		}else{
			error = false;
			$("#popupphone").addClass('error');
		}
	}
	
	
	//alert(error);
	if(error == false){
		return error;
	}else{
		
		$("#callme_button1").html('Please Wait...');
		$("#callme_button1").attr('disabled','disabled');
		
	}
}
function checkForm2(){
	var error = true;
	var name = $('#bname').val();
	var phone = $('#bphone').val();
	var captcha = $("#bcaptcha_code").val();
	if(name == ""){
		error = false;
		$("#name").addClass('error');
	}else{
		nmr = IsAlpha(name);
		if(nmr == true){
			$("#bname").removeClass('error');
		}else{
			error = false;
			$("#bname").addClass('error');
		}
	}
	if(phone == "" ||  phone.length < 10){
		error = false;
		$("#phone").addClass('error');
	}else{
		vnr = validateNumber(phone)
		if(vnr == true){
			$("#bphone").removeClass('error');
		}else{
			error = false;
			$("#bphone").addClass('error');
		}
	}
	
	if(captcha == ""){
		error = false;
		$("#bcaptcha_code").addClass('error');
	}else{
		$("#bcaptcha_code").removeClass('error');
	}
	//alert(error);
	if(error == false){
		return error;
	}else{
		
		$("#callme_button2").html('Please Wait...');
		$("#callme_button2").attr('disabled','disabled');
		
	}
}


$('.enquire_now1').click(function(e){
     e.preventDefault();
     $('html,body').animate({
         scrollTop: $('#clovecontact1').offset().top - 80
     },200);
     $('#clovecontact1').find('input[name="name"]').focus();
 });
 
 $('.enquire_now1').click(function(e){
     e.preventDefault();
     $('html,body').animate({
         scrollTop: $('#clovecontact1').offset().top - 80
     },200);
     $('#clovecontact1').find('input[name="name"]').focus();
 });
 $('.appointment').click(function(e){
     e.preventDefault();
     $('html,body').animate({
         scrollTop: $('#clovecontact1').offset().top - 80
     },200);
     $('#clovecontact1').find('input[name="name"]').focus();
 });
 </script>

    </body>
</html>
