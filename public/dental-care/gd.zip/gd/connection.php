<?php 
$db_host = 'localhost';
//$db_name = 'reinvld2_exldentist';
//$db_user = 'reinvld2_exldentist';
$db_pass = 'SVotV96(GzYL';
class mysqli_class extends mysqli {
    public function __construct($host, $user, $pass, $db) {
        parent::__construct($host, $user, $pass, $db);
 
        if (mysqli_connect_error()) {
            die('Connect Error (' . mysqli_connect_errno() . ') '
                    . mysqli_connect_error());
        }
    }
}
$con = new mysqli_class($db_host, $db_user, $db_pass, $db_name);	   
date_default_timezone_set('Asia/Calcutta');	   

?>