<?php
ob_start();
session_start();
// /**
//  * ClickToCall
//  * @Created By: Rohit (01 sep 2023)
//  * @Description: Handling Click to call Functionality
//  */


$curl = curl_init();

$USER_ID = "68932213";
$TOKEN = "W6bkezPTvA6xhVf2NoaI";
//$FROM = "9745073555";
$FROM = "8714608881";
$TO = mysqli_real_escape_string( $con, $phone );

curl_setopt_array($curl, array(
     CURLOPT_URL => 'https://s-ct3.sarv.com/v2/clickToCall/para?&user_id='.$USER_ID.'&token='.$TOKEN.'&from='.$FROM.'&to='.$TO,
     CURLOPT_RETURNTRANSFER => true,
     CURLOPT_ENCODING => "",
     CURLOPT_MAXREDIRS => 10,
     CURLOPT_TIMEOUT => 30,
     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
     CURLOPT_CUSTOMREQUEST => "POST",
     CURLOPT_POSTFIELDS => "",
     CURLOPT_HTTPHEADER => array(
     "cache-control: no-cache"
     ),
));


$response = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);


if ($err) {
     echo "cURL Error #:" . $err;
} else {
    echo $response;
}

?>